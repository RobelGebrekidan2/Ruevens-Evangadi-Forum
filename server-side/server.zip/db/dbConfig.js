const mysql2 = require("mysql2");
const dbconnection = mysql2.createPool({
  user: process.env.USER,
  database: process.env.DATABASE,
  host: "localhost",
  password: process.env.PASSWORD,
  connectionLimit: 10,
  // user: "sql10695190",
  // database: "sql10695190",
  // host: "localhost",
  // password: "QFql1MMgu4",

  // connectionLimit: 10,
});

// to solve the callback hell
module.exports = dbconnection.promise();
